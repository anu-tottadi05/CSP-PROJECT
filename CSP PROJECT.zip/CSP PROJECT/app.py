from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mail import Mail, Message
from datetime import datetime,timedelta
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from flask import jsonify

import sqlite3
import os
import requests
import base64

# Mail Configuration &  Load Environment Variables

load_dotenv()
API_KEY = os.getenv("API_KEY")
if not API_KEY:
    raise RuntimeError("OPENWEATHER API_KEY not set")

# Vizag Locations with Coordinates

vizag_locations = {
    "mvp colony": {"lat": 17.7398, "lon": 83.3195},
    "gajuwaka": {"lat": 17.6868, "lon": 83.1714},
    "seethammadhara": {"lat": 17.7450, "lon": 83.3125},
    "dwaraka nagar": {"lat": 17.7260, "lon": 83.3160},
    "rushikonda": {"lat": 17.7845, "lon": 83.3820},
    "akkayyapalem": {"lat": 17.7318, "lon": 83.3054},
    "siripuram": {"lat": 17.7128, "lon": 83.3169},
    "jagadamba junction": {"lat": 17.7171, "lon": 83.3086},
    "nad junction": {"lat": 17.7615, "lon": 83.2228},
    "kurmannapalem": {"lat": 17.6830, "lon": 83.1581},
    "gopalapatnam": {"lat": 17.7100, "lon": 83.1900},
    "pm palem": {"lat": 17.7787, "lon": 83.3580},
    "bheemunipatnam": {"lat": 17.8880, "lon": 83.4523},
    "anakapalle": {"lat": 17.6913, "lon": 83.0033},
    "kancharapalem": {"lat": 17.7337, "lon": 83.2919},
    "kommadi": {"lat": 17.7911, "lon": 83.3651},
    "pendurthi": {"lat": 17.7634, "lon": 83.1852},
    "yendada": {"lat": 17.7746, "lon": 83.3505},
    "sheela nagar": {"lat": 17.6841, "lon": 83.2011},
    "malkapuram": {"lat": 17.6803, "lon": 83.2632}
}

# Flask App Setup

app = Flask(__name__)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')  # From .env
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')  # From .env
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_USERNAME')

mail = Mail(app)
app.secret_key = 'your_secret_key'  # Change this in production
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
DB_NAME = 'database.db'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Initialize the database and create the users table
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            phno TEXT,
            location TEXT,
            profile_image TEXT
        )
    ''')


    c.execute('''
        CREATE TABLE IF NOT EXISTS volunteers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL,
            interest TEXT NOT NULL,
            location TEXT NOT NULL
        )
    ''')

    c.execute('''
    CREATE TABLE IF NOT EXISTS plantation_uploads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        area TEXT NOT NULL,
        gps_location TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        before_image TEXT NOT NULL,
        after_image TEXT NOT NULL
    )
''')

    c.execute('''
        CREATE TABLE IF NOT EXISTS rewards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            amount_spent REAL NOT NULL,
            reward_amount REAL NOT NULL,
            bill_image TEXT NOT NULL,
            submitted_at TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

    conn = sqlite3.connect('donations.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS donations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            amount INTEGER NOT NULL,
            method TEXT NOT NULL,
            message TEXT,
            date TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

AQI_MAP = {
    1: ("🟢 Good", 20.9, "#a8e05f"),
    2: ("🟡 Fair", 20.7, "#fdd74b"),
    3: ("🟠 Moderate", 20.5, "#fe9b57"),
    4: ("🔴 Poor", 20.3, "#fe6a69"),
    5: ("🟣 Very Poor", 20.0, "#a97abc"),
}

vizag_locations = {
    "gajuwaka": {"lat": 17.7000, "lon": 83.2167},  # from wiki :contentReference[oaicite:1]{index=1}
    "mvp colony": {"lat": 17.7500, "lon": 83.3333},  # approximate center from page :contentReference[oaicite:2]{index=2}
    "dwaraka nagar": {"lat": 17.7282, "lon": 83.3081},  # previously cited from external :contentReference[oaicite:3]{index=3}
    "kurmannapalem": {"lat": 17.6850, "lon": 83.1675},  # from wiki coordinates :contentReference[oaicite:4]{index=4}
    "rushikonda": {"lat": 17.8025, "lon": 83.3853},  # from wiki :contentReference[oaicite:5]{index=5}
    "kancharapalem": {"lat": 17.6830, "lon": 83.3000},  # approximate from locality data :contentReference[oaicite:6]{index=6}
    "seethammadhara": {"lat": 17.7409, "lon": 83.3168},  # from earlier :contentReference[oaicite:7]{index=7}
    "arilova": {"lat": 17.7580, "lon": 83.3270},  # approximate based on transport map :contentReference[oaicite:8]{index=8}
    "bheemili": {"lat": 17.8900, "lon": 83.4525},  # earlier cited :contentReference[oaicite:9]{index=9}
    "pm palem": {"lat": 17.6850, "lon": 83.1675},  # PM Palem is same as Kurmannapalem area :contentReference[oaicite:10]{index=10}
    "yendada": {"lat": 17.7697, "lon": 83.3540}  # user-provided; regional consistency
}
API_KEY = '8143e92a62b8d9933ad9be3da966bac3'


@app.route('/aqi-status', methods=['GET','POST'])
def aqi_status():
    query = request.form.get("location", "").strip().lower() if request.method=='POST' else None
    if query and query in vizag_locations:
        to_check = {query: vizag_locations[query]}
    else:
        if query:
            flash(f"Location '{query}' not recognized—showing all areas.", "warning")
        to_check = vizag_locations

    results = []
    for area, coord in to_check.items():
        aqi = status = oxygen = comp = color = None
        weather = {}
        lat, lon = coord['lat'], coord['lon']
        # fetch AQI + pollutants
        try:
            r = requests.get("https://api.openweathermap.org/data/2.5/air_pollution",
                             params={"lat":lat, "lon":lon, "appid":API_KEY})
            r.raise_for_status()
            lst = r.json().get("list", [])
            if lst:
                main = lst[0]["main"]
                comp = lst[0].get("components", {})
                aqi = main.get("aqi")
                status, oxygen, color = AQI_MAP.get(aqi, ("⚫ Unknown", 19.5, "#999"))
            else:
                raise ValueError("Empty list")
        except Exception as e:
            print("AQI error", area, e)
            aqi = status = oxygen = comp = color = None

        # fetch weather
        try:
            w = requests.get("https://api.openweathermap.org/data/2.5/weather",
                             params={"lat":lat, "lon":lon, "appid":API_KEY, "units":"metric"})
            w.raise_for_status()
            wj = w.json()
            weather = {
                "temp": wj["main"]["temp"],
                "humidity": wj["main"]["humidity"],
                "wind": wj["wind"].get("speed", "N/A"),
                "desc": wj["weather"][0]["description"].title(),
            }
        except Exception as e:
            print("Weather error", area, e)
            weather = {"temp":"N/A","humidity":"N/A","wind":"N/A","desc":"N/A"}

        results.append({
            "location": area.title(),
            "aqi": aqi or "N/A",
            "status": status or "⚫ Unknown",
            "oxygen": oxygen if oxygen is not None else "N/A",
            "components": comp or {},
            "color": color or "#999",
            "weather": weather
        })
    return render_template("oxygen_live.html", results=results)


# Signup Route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        phno = request.form['phno']
        location = request.form['location']
        image_file = request.files.get('image_url')

        if password != confirm_password:
            flash("Passwords do not match.", "error")
            return redirect(url_for('signup'))

        image_filename = ''
        if image_file and allowed_file(image_file.filename):
            image_filename = secure_filename(username + "_" + image_file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
            image_file.save(image_path)

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()

        try:
            c.execute("INSERT INTO users (username, email, password, phno, location, profile_image) VALUES (?, ?, ?, ?, ?, ?)",
                      (username, email, password, phno, location, image_filename))
            conn.commit()
            flash("Signup successful! Please log in.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username or Email already exists.", "error")
        finally:
            conn.close()

    return render_template('signup.html')


# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()

        if user:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            flash("Invalid username or password.", "error")

    return render_template('login.html')


# Home Route (only accessible after login)
@app.route('/home')
def home():
    if 'username' not in session:
        flash("Please log in to access this page.", "error")
        return redirect(url_for('login'))
    return render_template('home.html', username=session['username'])


# Logout Route
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))

#welcome route
@app.route('/')
def welcome():
    return render_template('welcome.html')


# Optional routes (add templates as needed)
@app.route('/oxygen')
def oxygen(): return render_template('oxygen.html')

#graph route
@app.route('/graph')
def graph(): return render_template('graph.html')

#graph route
@app.route('/graph', methods=['POST'])
def graph_data():
    data = request.get_json()
    area = data.get('area', '').strip().lower()
    view_type = data.get('viewType', 'daily')
    date_str = data.get('date', datetime.now().strftime('%Y-%m-%d'))
    start_date = datetime.strptime(date_str, '%Y-%m-%d')

    coords = vizag_locations.get(area)
    if not coords:
        return jsonify({"error": "Invalid area"}), 400

    lat, lon = coords['lat'], coords['lon']
    pollution_result = []
    trees_result = []

    if view_type == 'daily':
        for i in range(7):
            target_date = start_date + timedelta(days=i)
            date_label = target_date.strftime('%Y-%m-%d')

            # Fetch PM2.5 pollution data
            try:
                r = requests.get("http://api.openweathermap.org/data/2.5/air_pollution/history", params={
                    "lat": lat,
                    "lon": lon,
                    "start": int(target_date.timestamp()),
                    "end": int((target_date + timedelta(days=1)).timestamp()),
                    "appid": API_KEY
                })
                r.raise_for_status()
                aqi_data = r.json().get('list', [])
                if aqi_data:
                    pm25 = aqi_data[0]["components"].get("pm2_5", 0)
                else:
                    pm25 = 0
            except Exception as e:
                print("Pollution fetch error:", e)
                pm25 = 0

            # Count trees planted on that date
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute('''
                SELECT COUNT(*) FROM plantation_uploads 
                WHERE area LIKE ? AND DATE(timestamp) = ?
            ''', (f"%{area}%", date_label))
            trees = c.fetchone()[0]
            conn.close()

            pollution_result.append({"date": date_label, "pm25": pm25})
            trees_result.append({"date": date_label, "trees": trees})

    elif view_type == 'monthly':
        # Group by month for 6 months
        for i in range(6):
            month = (start_date - timedelta(days=i*30)).strftime('%Y-%m')
            month_label = datetime.strptime(month, "%Y-%m").strftime("%b %Y")

            # Dummy average PM2.5 (real monthly average would need storing historical data)
            pm25 = 40 - i * 2  # or replace with better logic
            # Count trees in month
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute('''
                SELECT COUNT(*) FROM plantation_uploads 
                WHERE area LIKE ? AND strftime('%Y-%m', timestamp) = ?
            ''', (f"%{area}%", month))
            trees = c.fetchone()[0]
            conn.close()

            pollution_result.append({"month": month_label, "pm25": pm25})
            trees_result.append({"month": month_label, "trees": trees})

    return jsonify({
        "pollution": pollution_result,
        "trees": trees_result
    })


@app.route('/fund')
def fund(): return render_template('fund.html')


# Start Donation Route
@app.route('/start_donation', methods=['POST'])
def start_donation():
    # Save form data to session temporarily
    session['donation_data'] = {
        'name': request.form['name'],
        'phone': request.form['phone'],
        'amount': request.form['amount'],
        'method': request.form['method'],
        'message': request.form['message']
    }
    return redirect(url_for('confirm_donation'))


# Confirm Donation Route
@app.route('/confirm_donation')
def confirm_donation():
    data = session.get('donation_data')
    if not data:
        flash("No donation data found.", "error")
        return redirect(url_for('fund'))
    return render_template('confirm_donation.html', data=data)


#submit_donation Route
@app.route('/submit_donation', methods=['POST'])
def submit_donation():
    data = session.pop('donation_data', None)
    if not data:
        flash("Session expired or invalid submission.", "error")
        return redirect(url_for('fund'))

    donated_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    conn = sqlite3.connect('donations.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO donations (name, phone, amount, method, message, date)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (data['name'], data['phone'], data['amount'], data['method'], data['message'], donated_at))
    conn.commit()
    conn.close()
    
    flash("🎉 Thank you! Your donation was recorded.", "success")
    return redirect(url_for('donation_list'))


# Donation List Route
@app.route('/donation_list')
def donation_list():
    conn = sqlite3.connect('donations.db')
    c = conn.cursor()
    c.execute('SELECT name, phone, amount, method, message,date FROM donations ORDER BY id DESC')
    donations = c.fetchall()
    conn.close()
    return render_template('donation_list.html', donations=donations)


# Volunteer Route
@app.route('/volunteer', methods=['GET', 'POST'])
def volunteer():
    if request.method == 'POST':
        name = request.form.get('name')
        phone = request.form.get('phone')
        email = request.form.get('email')
        interest = request.form.get('interest')
        location = request.form.get('location')

        try:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute('''
                INSERT INTO volunteers (name, phone, email, interest, location)
                VALUES (?, ?, ?, ?, ?)
            ''', (name, phone, email, interest, location))
            conn.commit()
            conn.close()

            suggestions = {
                "plantation": {
                   "Gajuwaka": ["Steel Plant Road divider", "Near Gajuwaka College Ground"],
        "MVP Colony": ["MVP Double Road Median", "Sector 5 Park Boundary"],
        "Dwaraka Nagar": ["RTC Complex divider", "Near Diamond Park Wall"],
        "Kurmannapalem": ["NH Roadside near flyover", "College Backside Green Belt"],
        "Rushikonda": ["VUDA Park Hill Area", "Gitam Entrance Patch"],
        "Kancharapalem": ["Railway Track Side", "Rythu Bazaar Compound"],
        "Seethammadhara": ["HB Colony divider", "Beside VUDA Apartments"],
        "Arilova": ["Temple Hillside", "Ayurvedic Hospital Compound"],
        "Bheemili": ["Beach Entrance Strip", "Fortside Park Zone"],
        "PM Palem": ["Cricket Stadium Backside", "Kommadi Road Divider"],
        "Yendada": ["Iskcon Temple Footpath", "VUDA Colony Entry Zone"],
        "Pedawaltair": ["KG Hospital Boundary", "Main Road Median Strip"],
        "Lawsons Bay": ["Park Side Trail", "Beachfront Divider"],
        "Jagadamba Junction": ["Clock Tower Back Lane", "Open lot behind Theatre"],
        "Visalakshi Nagar": ["Hillview Park Side", "Sagar Nagar Link Strip"],
        "Steel Plant Township": ["Sector-2 Playground Edge", "Inside Township Roadside"]
                },
                "garbage": {
                     "Gajuwaka": ["Gajuwaka Market Road", "Bus Depot Area"],
        "MVP Colony": ["Fish Market Lane", "Sector 9 Garbage Zone"],
        "Dwaraka Nagar": ["5th Lane Drains", "Near Shopping Complex Bins"],
        "Kurmannapalem": ["Near Auto Stand", "Old Bus Stop Back Lane"],
        "Rushikonda": ["Beach Trash Zone", "Parking Bay Corners"],
        "Kancharapalem": ["Backstreets of Railway Quarters", "Near Old Cinema Hall"],
        "Seethammadhara": ["Opp. Bus Stop Drainage", "HB Colony Garbage Lane"],
        "Arilova": ["Health Arena Side Path", "Temple Backlane"],
        "Bheemili": ["Market Area Garbage", "Bus Stop Dustbin Area"],
        "PM Palem": ["Near Local Vegetable Market", "Roadside Dustbin Overflow"],
        "Yendada": ["Sloped area below CMR", "Service Road Behind Complex"],
        "Pedawaltair": ["Medical Street Drain", "Backlane near Police Station"],
        "Lawsons Bay": ["Beachside Trash Zones", "Road Bends Dustbins"],
        "Jagadamba Junction": ["Theatre Backside Lane", "Bus Stop Overflow Point"],
        "Visalakshi Nagar": ["Circle No. 2 Dustbin Area", "Hill Road Trash Line"],
        "Steel Plant Township": ["Sector-5 Dustbin Lane", "NH Service Road Debris"]
                },
                "awareness": {
                   "Gajuwaka": ["Sri Krishna College Awareness Drive", "Steel Plant Entrance Rally"],
        "MVP Colony": ["Sector 3 Parks", "MVP Bus Stop Flash Cards"],
        "Dwaraka Nagar": ["Complex Area Pamphlet Distribution", "RTC Complex Corner Awareness"],
        "Kurmannapalem": ["Tech College Gate", "Flyover Entry Rally"],
        "Rushikonda": ["Beach Awareness Boards", "Gitam College Seminar"],
        "Kancharapalem": ["School Campaign in Block 2", "Community Meeting Hall Awareness"],
        "Seethammadhara": ["Main Park Poster Walk", "Housing Board Door-to-Door"],
        "Arilova": ["Temple Entry Posters", "VUDA Health Arena Group Talk"],
        "Bheemili": ["Fort Premises Awareness", "Village Roadside Campaign"],
        "PM Palem": ["Near Cricket Stadium Crowd", "Community Ground PA"],
        "Yendada": ["CMR Mall Junction Outreach", "Colony Park Sessions"],
        "Pedawaltair": ["Medical Camp Awareness", "Walkthrough Poster Rally"],
        "Lawsons Bay": ["Shilparamam Events", "Park Flash Mob"],
        "Jagadamba Junction": ["Public Talk near Clock Tower", "Traffic Signal Posters"],
        "Visalakshi Nagar": ["Temple Steps PA", "School Gate Awareness Drive"],
        "Steel Plant Township": ["Sector 1 Community Hall", "Market Side Rally Point"]
                }
            }



            area_suggestions = suggestions.get(interest, {}).get(location, ["No suggestions available"])

            return render_template('volunteer_result.html',
                                   name=name,
                                   phone=phone,
                                   email=email,
                                   interest=interest,
                                   location=location,
                                   suggestions=area_suggestions)
        except Exception as e:
            print("Error saving to DB:", e)
            return "Error", 500
        
        

    return render_template('volunteer.html')


# Volunteer List Route
@app.route('/volunteer-list')
def volunteer_list():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM volunteers")
    volunteers = c.fetchall()
    conn.close()
    return render_template('volunteer_list.html', volunteers=volunteers)

#upload_plantation route
@app.route('/upload-plantation', methods=['POST'])
def upload_plantation():
    area = request.form.get('area')
    gps_location = request.form.get('location')
    timestamp = request.form.get('datetime')
    before_dataurl = request.form.get('before_image')
    after_dataurl = request.form.get('after_image')

    def save_image_from_dataurl(data_url, prefix):
        header, encoded = data_url.split(",", 1)
        file_ext = header.split("/")[1].split(";")[0]
        filename = f"{prefix}_{datetime.now().strftime('%Y%m%d%H%M%S')}.{file_ext}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        with open(filepath, "wb") as f:
            f.write(base64.b64decode(encoded))
        return filename

    try:
        before_filename = save_image_from_dataurl(before_dataurl, "before")
        after_filename = save_image_from_dataurl(after_dataurl, "after")

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            INSERT INTO plantation_uploads (area, gps_location, timestamp, before_image, after_image)
            VALUES (?, ?, ?, ?, ?)
        ''', (area, gps_location, timestamp, before_filename, after_filename))
        conn.commit()
        conn.close()
        flash("Upload successful!", "success")
        return redirect(url_for('plantation_gallery'))
    except Exception as e:
        print("Upload Error:", e)
        flash("Upload failed!", "error")
        return redirect(url_for('upload'))

#plantation route
@app.route('/plantation-gallery')
def plantation_gallery():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id,area, gps_location, timestamp, before_image, after_image FROM plantation_uploads ORDER BY id DESC")
    uploads = c.fetchall()
    conn.close()
    return render_template('plantation_gallery.html', uploads=uploads)


@app.route('/upload')
def upload(): return render_template('upload.html')

#profile route
@app.route('/profile')
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT username, email, phno, location, profile_image FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()

    if user:
        user_data = {
            'username': user[0],
            'email': user[1],
            'phno': user[2],
            'location': user[3],
            'profile_image': user[4] or 'default.png'
        }
        return render_template('profile.html', user=user_data)
    else:
        flash("User not found", "error")
        return redirect(url_for('home'))

#reward route
@app.route('/rewards')
def rewards(): return render_template('rewards.html')

#submit_reward Route
@app.route('/submit_reward', methods=['POST'])
def submit_reward():
    if 'username' not in session:
        flash("You must be logged in to submit rewards.", "error")
        return redirect(url_for('login'))

    username = session['username']
    amount_spent = request.form.get('amountSpent')
    bill_image = request.files.get('billUpload')

    if not amount_spent or not bill_image or not allowed_file(bill_image.filename):
        flash("Please provide valid amount and image.", "error")
        return redirect(url_for('rewards'))

    try:
        amount_spent = float(amount_spent)
    except ValueError:
        flash("Amount must be a number.", "error")
        return redirect(url_for('rewards'))

    reward_amount = amount_spent + 50  # Bonus ₹50
    filename = secure_filename(username + "_reward_" + bill_image.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    bill_image.save(filepath)

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        INSERT INTO rewards (username, amount_spent, reward_amount, bill_image, submitted_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (username, amount_spent, reward_amount, filename, datetime.now().strftime('%Y-%m-%d %H:%M:%S')
))
    conn.commit()
    conn.close()

    flash(f"🎉 You earned ₹{reward_amount} cashback! please check show Reward Details..!", "success")
    return redirect(url_for('rewards'))

#show_rewards Route
@app.route('/show_rewards')
def show_rewards():
    if 'username' not in session:
        flash("Please log in to view your rewards.", "error")
        return redirect(url_for('login'))

    username = session['username']
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        SELECT amount_spent, reward_amount, bill_image, submitted_at
        FROM rewards WHERE username=? ORDER BY submitted_at DESC
    ''', (username,))
    rows = c.fetchall()
    conn.close()

    rewards = [{
        "amount_spent": row[0],
        "reward_amount": row[1],
        "bill_image": row[2],
        "submitted_at": row[3]
    } for row in rows]

    return render_template("reward_details.html", rewards=rewards)

#reward_details Route
@app.route('/reward_details')
def reward_details():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT bill_image, amount_spent, reward_amount, submitted_at FROM rewards")
    rows = cursor.fetchall()

    rewards = []
    total_combined = 0.0

    for row in rows:
        try:
            amount_spent = float(row['amount_spent']) if row['amount_spent'] else 0.0
        except ValueError:
            amount_spent = 0.0

        try:
            reward_amount = float(row['reward_amount']) if row['reward_amount'] else 0.0
        except ValueError:
            reward_amount = 0.0

        total_combined += amount_spent + reward_amount

        rewards.append({
            'bill_image': row['bill_image'],
            'amount_spent': amount_spent,
            'reward_amount': reward_amount,
            'submitted_at': row['submitted_at']
        })

    conn.close()
    return render_template("reward_details.html", rewards=rewards, total_combined=round(total_combined, 2))


#contact Route
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        if not (name and email and message):
            flash("Please fill all fields.", "error")
            return redirect(url_for('contact'))

        try:
            msg = Message(subject=f"New Contact Message from {name}",
                          sender=email,
                          recipients=['devagollu143@gmail.com'],
                          body=f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}")
            mail.send(msg)
            flash("Your message has been sent successfully!", "success")
        except Exception as e:
            print("Mail Error:", e)
            flash("Failed to send message. Please try again later.", "error")

        return redirect(url_for('contact'))

    return render_template('contact.html')


#help Route
@app.route('/help')
def help(): return render_template('help.html')


UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Upload_Profile Image Route
@app.route('/upload_profile_image', methods=['POST'])
def upload_profile_image():
    if 'username' not in session:
        return 'failed'

    file = request.files.get('image')

    if file and allowed_file(file.filename):
        # Optional: Get old image to delete it
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT profile_image FROM users WHERE username=?", (session['username'],))
        old_image = c.fetchone()[0]
        
        # Save new image
        filename = secure_filename(session['username'] + "_" + file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Delete old image (except default image)
        if old_image and old_image != 'default.png':
            old_path = os.path.join(app.config['UPLOAD_FOLDER'], old_image)
            if os.path.exists(old_path):
                os.remove(old_path)

        # Update DB
        c.execute("UPDATE users SET profile_image=? WHERE username=?", (filename, session['username']))
        conn.commit()
        conn.close()
        return 'success'
    return 'failed'



@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT email, phno, location FROM users WHERE username=?", (session['username'],))
    user = c.fetchone()

    if request.method == 'POST':
        email = request.form['email']
        phno = request.form['phno']
        location = request.form['location']

        # ✅ Check if the new email belongs to another user
        c.execute("SELECT username FROM users WHERE email=? AND username!=?", (email, session['username']))
        existing = c.fetchone()

        if existing:
            conn.close()
            flash("This email is already used by another account.", "error")
            return redirect(url_for('edit_profile'))

        # ✅ Proceed with update
        c.execute('UPDATE users SET email=?, phno=?, location=? WHERE username=?',
                  (email, phno, location, session['username']))
        conn.commit()
        conn.close()

        flash("Profile updated successfully.", "success")
        return redirect(url_for('profile'))

    conn.close()

    if user:
        return render_template('edit_profile.html', email=user[0], phno=user[1], location=user[2])
    else:
        flash("User not found.", "error")
        return redirect(url_for('profile'))



if __name__ == '__main__':
    init_db()
    app.run(debug=True)
 